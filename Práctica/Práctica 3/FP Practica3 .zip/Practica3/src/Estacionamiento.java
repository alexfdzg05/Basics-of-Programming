public class Estacionamiento {
    private int numeroBicis;
    // número de bicis en ese momento en el Estacionamiento
    private int numeroEstacionamiento;
    //identificador del Estacionamiento
    private GestionEstacionamiento misCargadores;
   // estructura para guardar las bicis en el estacionamiento

    public Estacionamiento() {
    numeroBicis = Utilidad.NUMERO_BICIS_ESTACIONAMIENTO;
    numeroEstacionamiento = Utilidad.asignaNumeroEstacionamiento();
        // la constante NUMEROBICISESTACIONAMIENTO de la clase Utilidad
        // asigna un identificador único a la propiedad numeroEstacionamiento
        // generado en la clase Utilidad por el método asignaNumeroEstacionamiento()
    misCargadores = new GestionEstacionamiento();
        // inicializa el almacen de bicis  que esta en la propiedad miscargadores con el número de bicis
        //máximo llamando al constructor de la clase GestionEstacionamiento

    }

    public Bicicleta cogeBici(Usuario miUsuario) {
        // metodo que simula el alquiler de una bici
        // sacando la bici de misCargadores y decrementado el número de bicis del
        // estacionamiento
        Bicicleta resul = null;
        if (numeroBicis>0){
            resul = misCargadores.sacaBici();
            resul.setUsuario(miUsuario);
            numeroBicis--;
        }
        return resul;
    }

    public boolean dejaBici(Bicicleta bici) {
        // metodo que simula el devolver una bici
        // introduciendo  la bici en misCargadores e incrementado el número de bicis del
        // estacionamiento
        boolean resul = false;
        GestionEstacionamiento accion = null;
        if (numeroBicis<15) {
            resul = true;
            misCargadores.introduceBici(bici);
            numeroBicis++;
        }
        return resul;
    }

    public int getNumeroBicis() {
        //devuelve el número de bicis que hay en el estacionamiento
        return numeroBicis;
    }
}
