import java.util.Scanner;


public class GestionaBicis {
    // Realizado por Alejandro Fernandez Guerrero bu0024
    // las pruebas las haremos sobre dos estacionamientos estacion1 y estacion2
    Estacionamiento estacion1 = null, estacion2 = null;
    //Inicializamos la estructura para guardar las bicis que están en alquiler
    Alquiladas alquiladas = null;

    public static void main(String[] args) {
        // creamos un objeto de la clase para poder ejecutar el programa
        GestionaBicis miObjeto = new GestionaBicis();
    }

    public GestionaBicis() {
        //constructor de la clase que inicia el programa
        int opcion;
        do {
            opcion = menu();
            ejecutarOpcion(opcion);
        } while (opcion != 0);

    }

    public int menu() {
        int opt;
        System.out.println("1. Crear/Inicializar estacionamientos.");
        System.out.println("2. Coger bicicleta.");
        System.out.println("3. Dejar bicicleta.");
        System.out.println("4. Número de bicicletas actuales del estacionamiento.");
        System.out.println("5. Número de bicicletas alquiladas en este momento.");
        System.out.println("0. Finalizar la ejecución.");
        String msg = "Introduzca un número comprendido entre 0 y 5: ";
        opt = leerNumero(0, 5, msg);
        System.out.println();
        return opt;
    }

    public int leerNumero(int n1, int n2, String texto) {
        //método que me permite pedir un número y valida que este entre un límite
        // mínimo y uno máximo pasados por parámetro, asi como poner un texto en pantalla
        // idicando que tiene que hacer el usuario
        Scanner teclado = new Scanner(System.in);
        int num;
        do {
            System.out.print(texto);
            num = teclado.nextInt();
            if (num < n1)
                System.out.println("El número " + num + " no es mayor que " + n1);
            else if (num > n2)
                System.out.println("El número " + num + " no es menor que " + n2);
        } while (num < n1 || num > n2);
        return num;
    }

    public void ejecutarOpcion(int opcion) {
        //Ejecuta la acción elegida por el usuario
        int esta;
        switch (opcion) {
            case 1: // inicializa Estacionamientos
                //código
                estacion1 = new Estacionamiento();
                estacion2 = new Estacionamiento();
                alquiladas = new Alquiladas();
                System.out.println("Estacionamientos 1 y 2 creados!");
                break;
            case 2://Alquilar Bici
                //código
                esta = leerNumero(1, 2, "Elija el estacionamiento 1 o 2: ");
                if (esta == 1) {
                    if (estacion1 != null) {
                        Bicicleta bici;
                        Usuario usuario = pideUsuario();
                        if (estacion1.getNumeroBicis() > 0) {
                            bici = estacion1.cogeBici(usuario);
                            System.out.println("El usuario " + bici.getUsuario().getNombre() + " con número " +
                                    bici.getUsuario().getNumeroUsuario() + " ha alquilado la bici: " + bici.getNumeroBici());
                            System.out.println("Número de bicis disponibles en el Estacionamiento 1: " + estacion1.getNumeroBicis());
                            alquiladas.introduceBici(bici);
                        } else {
                            System.out.println("Operacion imposible de realizar, estacionamiento 1 vacío");
                            System.out.println("Número de bicis disponibles en el Estacionamiento 1: 0");

                        }
                    } else {
                        System.out.println("Los estacionamientos no han sido creados");
                    }
                } else {
                    if (estacion2 != null) {
                        if (estacion2.getNumeroBicis() > 0) {
                            Bicicleta bici;
                            Usuario usuario = pideUsuario();
                            bici = estacion2.cogeBici(usuario);
                            System.out.println("El usuario " + bici.getUsuario().getNombre() + " con número " +
                                    bici.getUsuario().getNumeroUsuario() + " ha alquilado la bici: " + bici.getNumeroBici());
                            System.out.println("Número de bicis disponibles en el Estacionamiento 2: " + estacion2.getNumeroBicis());
                            alquiladas.introduceBici(bici);
                        } else {
                            System.out.println("Operacion imposible de realizar, estacionamiento 2 vacío");
                            System.out.println("Número de bicis disponibles en el Estacionamiento 2: 0");
                        }
                    } else {
                        System.out.println("Los estacionamientos no han sido creados");
                    }
                }
                break;
            case 3://dejar Bici
                //código
                int l = leerNumero(0, 3, "Elija el estacionamiento 1 o 2: ");
                if (l == 1) {
                    if (estacion1 != null) {
                        if (estacion1.getNumeroBicis() < 15) {
                            Bicicleta bici1 = alquiladas.eliminaBici();
                            estacion1.dejaBici(bici1);
                            System.out.println("El usuario " + bici1.getUsuario().getNombre() + " con número " +
                                    bici1.getUsuario().getNumeroUsuario() + " ha dejado la bici: " + bici1.getNumeroBici());
                            System.out.println("El número de cargadores disponibles en el Estacionamiento 1 es: " + (Utilidad.NUMERO_BICIS_ESTACIONAMIENTO - estacion1.getNumeroBicis()));

                        } else {
                            System.out.println("Operacion imposible de realizar, estacionamiento 1 lleno");
                        }
                    } else {
                        System.out.println("Los estacionamientos no han sido creados");
                    }
                }
                if (l == 2) {
                    if (estacion2 != null) {
                        if (estacion2.getNumeroBicis() < 15) {
                            Bicicleta bici1 = alquiladas.eliminaBici();
                            estacion2.dejaBici(bici1);
                            System.out.println("El usuario " + bici1.getUsuario().getNombre() + " con número " +
                                    bici1.getUsuario().getNumeroUsuario() + " ha dejado la bici: " + bici1.getNumeroBici());
                            System.out.println("El número de cargadores disponibles en el Estacionamiento 2 es: " + (Utilidad.NUMERO_BICIS_ESTACIONAMIENTO - estacion2.getNumeroBicis()));
                        } else {
                            System.out.println("Operacion imposible de realizar, estacionamiento 2 lleno");
                        }
                    } else {
                        System.out.println("Los estacionamientos no han sido creados");
                    }
                }
                break;
            case 4://número de bicis de un estacionamiento
                //código
                int n = leerNumero(0, 3, "Elija el estacionamiento 1 o 2: ");
                if (n == 1) {
                    if (estacion1 != null) {
                        System.out.println("El número de bicis del estacionamiento 1 es: " + estacion1.getNumeroBicis());
                    } else {
                        System.out.println("Los estacionamientos no han sido creados");
                    }
                } else {
                    if (estacion2 != null) {
                        System.out.println("El número de bicis del estacionamiento 2 es: " + estacion2.getNumeroBicis());
                    } else {
                        System.out.println("Los estacionamientos no han sido creados");
                    }
                }
                break;
            case 5://número de bicis alquiladas en ese momento además de los huecos libres en cada estacionamiento
                //código
                if (estacion1 != null && estacion2 != null) {
                    System.out.println("El número de bicis alquiladas en este momento es: " + alquiladas.getNumeroBicisAlquiladas());
                    System.out.println("Huecos libres en el estacionamiento 1: " + (Utilidad.NUMERO_BICIS_ESTACIONAMIENTO - estacion1.getNumeroBicis()));
                    System.out.println("Huecos libres en el estacionamiento 2: " + (Utilidad.NUMERO_BICIS_ESTACIONAMIENTO - estacion1.getNumeroBicis()));
                } else {
                    System.out.println("Los estacionamientos no han sido creados");
                }
                break;

            case 0:
                System.out.println("Adiós");
                break;
        }

    }

    public Usuario pideUsuario() {
        // método que genera un usuario con datos aleatorios pero con identificador único
        //  utilizando el método de la clase Utilidad generaUsuario()
        Usuario resul;
        resul = Utilidad.generaUsuario();
        return resul;
    }
}
