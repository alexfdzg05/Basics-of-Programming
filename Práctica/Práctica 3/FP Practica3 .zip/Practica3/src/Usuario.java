public class Usuario {
    private String nombre;
    private int numeroUsuario;
    private String telefono;
    private String tarjeta;

    public Usuario(String nombre, int numeroUsuario, String telefono, String tarjeta) {
    this.nombre = nombre;
    this.numeroUsuario = numeroUsuario;
    this.telefono = telefono;
    this.tarjeta = tarjeta;
    }

    public Usuario(int numeroUsuario) {
        this.nombre = "";
        this.numeroUsuario = numeroUsuario;
        this.tarjeta = "";
        this.telefono = "";
        // constructor que inicializa un objeto Usuario con datos vacios
        // pero con identificador único pasado por parámetro
        //código
    }



    public void setNombre(String nombre) {
    this.nombre = nombre;
    }



    public void setTelefono(String telefono) {
    this.telefono = telefono;
    }



    public void setTarjeta(String tarjeta) {
    this.tarjeta = tarjeta;
    }

    public String getNombre() {
        return nombre;
    }

    public int getNumeroUsuario() {
        return numeroUsuario;
    }
}
