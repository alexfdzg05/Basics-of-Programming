public class Bicicleta {
    private int numeroBici;
    private int bateria;
    private Usuario usuario;

    public Bicicleta() {
        //constructor a la propiedad numeroBici le asigna un identificador único generado en la
        //clase Utilidad por el método asignaNumeroBici()
        numeroBici = Utilidad.asignaNumeroBici();
        bateria = Utilidad.CARGA_MAXIMA;
    }

    public void setNumeroBici(int numeroBici) {
        this.numeroBici = numeroBici;
    }

    public void descargaBateria(int cantidad) {
        if (bateria < cantidad) {
            bateria = 0;
        } else {
            bateria -= cantidad;
        }
    }

    public void cargaBateria(int carga) {
        bateria += carga;
        if (bateria > 100){
            bateria = 100;
        }
    }

    public void setUsuario(Usuario usuario1) {
        usuario = usuario1;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public int getNumeroBici() {
        return numeroBici;
    }

    @Override
    public String toString() {

        return "numeroBici=" + numeroBici + " , " + "bateria =" + bateria + " , " + "usuario=" + usuario;
    }
}
