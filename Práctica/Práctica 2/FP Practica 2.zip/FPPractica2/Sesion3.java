package FPPractica2;

import java.util.Scanner;

public class Sesion3 {
    //Realizado por Alejandro Fernández Guerrero bu0024 IWSIM11
    public static void main(String[] args) {
        int opcion;
        do {
            opcion = menu();
            switch (opcion) {
                case 1:
                    Sesion4.dibujarTrianguloRecursivo(leerNumero(5, 30), leerCaracter());
                    break;
                case 2:
                    dibujarCuadrado(leerNumero(10, 35), leerCaracter());
                    break;
                case 3:
                    System.out.println("El resultado es: "+Sesion4.multiplicarRecursivo(leerNumero(0, 20), leerNumero(0, 20)));
                    break;
                case 4:
                    Sesion4.tablaDeMultiplicar(leerNumero(0, 10));
                    break;
            }
        } while (opcion != 5);
        System.out.println("See you later!");
    }

    public static int menu() {
        int opcion;
        System.out.println();
        System.out.println("Seleccione entre las siguientes opciones: ");
        System.out.println("(1)Dibujar un triángulo rectángulo ");
        System.out.println("(2)Dibujar un cuadrado ");
        System.out.println("(3)Multiplicar dos números ");
        System.out.println("(4)Escribir una tabla de multiplicar ");
        System.out.println("(5)Finalizar la ejecución ");
        opcion = leerNumero(1, 5);
        return opcion;
    }

    public static int leerNumero(int minimo, int maximo) {
        Scanner teclado = new Scanner(System.in);
        int x1;
        do {
            System.out.print("Introduzca un numero entre " + minimo + " y " + maximo + ": ");
            x1 = teclado.nextInt();
        } while (x1 < minimo || x1 > maximo);
        return x1;
    }

    public static char leerCaracter() {
        Scanner teclado = new Scanner(System.in);
        char caracter;
        System.out.print("Introduce un carácter que no sea alfanumérico: ");
        caracter = teclado.next().charAt(0);
        if ((caracter >= 'a' && caracter <= 'z') || (caracter >= 'A' && caracter <= 'Z') || (caracter >= '0' && caracter <= '9')) {
            do {
                System.out.println("ERROR: no pueden ser números ni letras");
                System.out.print("Introduce un carácter que no sea alfanumérico: ");
                caracter = teclado.next().charAt(0);
            } while ((caracter >= 'a' && caracter <= 'z') || (caracter >= 'A' && caracter <= 'Z') || (caracter >= '0' && caracter <= '9'));
        }
        return caracter;
    }

    public static void dibujarTriangulo(int base, char caracter) {
        System.out.println("Dame el número de líneas del triángulo: ");
        for (int i = 0; i <= base; i++) {
            for (int n = 0; n < i; n++) {
                System.out.print(caracter);
            }
            System.out.println();
        }
    }

    public static void dibujarCuadrado(int lado, char caracter) {
        System.out.println("Dame el número de líneas del cuadrado: ");
        for (int i = 0; i < lado; i++) {
            System.out.println();
            for (int n = 0; n < lado; n++)
                System.out.print(" " + caracter + " ");
        }
    }

    public static int multiplicarIterativo(int numero2, int numero3) {
        int resultado = 0;
        if (numero2 < numero3) {
            for (int i = 0; i < numero3; i++) {
                resultado += numero2;
            }
        } else {
            for (int i = 0; i < numero2; i++) {
                resultado += numero3;
            }
        }
        System.out.println(numero2 + " x " + numero3 + " = " + resultado);
        return resultado;
    }

    public static void tablaDeMultiplicar(int numero) {
        int n = 0;
        for (int i = 0; i <= 10; i++) {
            int resultado1 = numero * n;
            System.out.println(numero + " x " + n + " = " + resultado1);
            System.out.println();
            n = n + 1;
        }
    }

}
