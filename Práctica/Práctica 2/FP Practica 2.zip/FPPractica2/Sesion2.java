package FPPractica2;

import java.util.Scanner;

public class Sesion2 {
    //Realizado por Alejandro Fernández Guerrero bu0024 IWSIM11

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        //triángulo
        int numero;
        System.out.println("Dame el número de líneas del triángulo ");
        do {
            System.out.print("Dame un numero entero entre 5 y 30: ");
            numero = teclado.nextInt();
        } while (numero < 5 || numero > 30);

        for (int i = 0; i <= numero; i++) {
            for (int n = 0; n < i; n++) {
                System.out.print('*');
            }
            System.out.println();
        }

//cuadrado
        System.out.println("Dame el número de líneas del cuadrado: ");
        int numero1;
        do {
            System.out.print("Dame un numero entero entre 10 y 35: ");
            numero1 = teclado.nextInt();
        } while (numero1 < 10 || numero1 > 35);

        for (int i = 0; i < numero1; i++) {
            System.out.println();
            for (int n = 0; n < numero1; n++)
                System.out.print(" * ");
        }
//multiplicación
        System.out.println();
        System.out.println("Introduce un número mayor o igual que 0 y menor o igual que 20: ");
        int numero2;
        numero2 = teclado.nextInt();
        while (numero2 < 0 || numero2 > 20) {
            System.out.println("Error: Dato fuera de parámetro");
            System.out.print("Dame un número que esté entre 0 y 20: ");
            numero2 = teclado.nextInt();
        }

        int numero3;
        System.out.print("Dame otro número que esté entre 0 y 20: ");
        numero3 = teclado.nextInt();
        while (numero3 < 0 || numero3 > 20) {
            System.out.println("Error: Dato fuera de parámetro");
            System.out.print("Dame un número que esté entre 0 y 20: ");
            numero3 = teclado.nextInt();
        }

        int resultado = numero2 * numero3;
        System.out.println(numero2 + " x " + numero3 + " = " + resultado);

//tabla de multiplicar
        int numero4;
        int n = 0;
        do {
            System.out.print("Introduzca un número del 1 al 10: ");
            numero4 = teclado.nextInt();
        } while ((numero4 > 10) || (numero4 < 0));

        for (int i = 0; i <= 10; i++) {
            int resultado1 = numero4 * n;
            System.out.println(numero4 + " x " + n + " = " + resultado1);
            System.out.println();
            n = n + 1;
        }
//final del código
    }
}