package FPPractica2;

import java.util.Scanner;

public class Sesion4 {
    //Realizado por Alejandro Fernández Guerrero bu0024 IWSIM11
    private static void dibujarLineaRecursivo(int numero, char c) {
        String linea = "";
        if (numero > 0) {
            linea += c;
            dibujarLineaRecursivo(numero - 1, c);
        }
        System.out.print(linea);
    }

    public static void dibujarTrianguloRecursivo(int base, char c) {
        if (base > 0) {
            dibujarTrianguloRecursivo(base - 1, c);
            System.out.println();
            dibujarLineaRecursivo(base, c);

        }
    }

    public static void dibujarCuadrado(int lado, char caracter) {
        System.out.println("Dame el número de líneas del cuadrado: ");
        for (int i = 0; i < lado; i++) {
            System.out.println();
            for (int n = 0; n < lado; n++)
                System.out.print(" " + caracter + " ");
        }
    }

    public static int multiplicarRecursivo(int numero1, int numero2) {
        int resultado = 0;
        if (numero2 != 0) {
            resultado = numero1 + multiplicarRecursivo(numero1, numero2 - 1);
        } else {
            resultado += 0;
        }
        return resultado;
    }

    public static void tablaDeMultiplicar(int numero1) {
        int numero2 = 0;
        while (numero2 <= 10) {
            System.out.println(numero1 + " x " + numero2 + " = " + multiplicarRecursivo(numero1, numero2));
            numero2++;
        }
    }
}


