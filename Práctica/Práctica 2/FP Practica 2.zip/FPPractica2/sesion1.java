// Realizado por Alejandro Fernández Guerrero bu0024 IWSIM11

package FPPractica2;

import java.util.Scanner;

public class sesion1 {
    //Realizado por Alejandro Fernández Guerrero bu0024 IWSIM11
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Seleccione entre las siguientes opciones: ");
        System.out.println("(1)Dibujar un triángulo rectángulo ");
        System.out.println("(2)Dibujar un cuadrado ");
        System.out.println("(3)Multiplicar dos números ");
        System.out.println("(4)Escribir una tabla de multiplicar ");
        System.out.println("(5)Finalizar la ejecución ");
        System.out.print("Opción: ");
        int opcion = teclado.nextInt();
        if (opcion == 1) {
            System.out.println("Usted escogió la opción (1)");
        } else if (opcion == 2) {
            System.out.println("Usted escogió la opción (2)");
        } else if (opcion == 3) {
            System.out.println("Usted escogió la opción (3)");
        } else if (opcion == 4) {
            System.out.println("Usted escogió la opción (4)");
        } else if (opcion == 5) {
            System.out.println("Usted escogió finalizar la ejecución (5)");
        } else {
            System.out.println("ERROR: Opción no válida");
        }
        //pedir número
        System.out.print("Introduce un número entre 0 y 100: ");
        int numero = teclado.nextInt();
        if ((numero > 100) || (numero < 5)) {
            System.out.println("Número no valido");
        } else {
            System.out.println("Se ha introducido el número: " + numero);
        }
        //mayor/menor y multiplo/no múltiplo
        System.out.print("Deme dos números enteros: ");
        int numero1 = teclado.nextInt();
        int numero2 = teclado.nextInt();
        if (numero1 > numero2) {
            if ((numero1 % numero2) == 0) {
                System.out.print("El número: " + numero1 + " es mayor que el número " + numero2 + " y " + numero2 + " es múltiplo de " + numero1);
            } else {
                System.out.print("El número: " + numero1 + " es mayor que el número " + numero2 + " y " + numero2 + " no es múltiplo de " + numero1);
            }
        } else {
            if ((numero1 % numero2) == 0) {
                System.out.print("El número: " + numero1 + " no es mayor que el número " + numero2 + " y " + numero2 + " es múltiplo de " + numero1);
            } else {
                System.out.print("El número: " + numero1 + " no es mayor que el número " + numero2 + " y " + numero2 + "no es múltiplo de " + numero1);
            }
        }
    }
    //aquí finaliza el código

}
